from rest_framework import serializers
from app_acpn.models import Info
from pprint import pprint

class InfoSerializer(serializers.Serializer):
    class Meta:
        field = '__all__'