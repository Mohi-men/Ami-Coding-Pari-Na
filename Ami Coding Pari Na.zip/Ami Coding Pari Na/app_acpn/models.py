from django.db import models

# Create your models here.
class Info(models.Model):
    user_id = models.CharField(max_length=50)
    input_values = models.TextField(max_length=300)
    timestamp = models.DateTimeField()

    def __str__(self):
        return self.user_id

class Visitor(models.Model):
    username = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.username
