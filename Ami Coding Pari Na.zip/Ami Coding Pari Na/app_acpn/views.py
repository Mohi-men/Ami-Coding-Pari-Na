from django.shortcuts import render, redirect
from django.contrib import messages
from app_acpn.models import *
from datetime import datetime
from rest_framework.response import Response
from rest_framework.decorators import api_view

from app_acpn.serializers import InfoSerializer


# Create your views here.
def index(request):
    if "is_logged" not in request.session:
        return redirect('/')
    else:
        if request.method == "POST":
            input_values = request.POST['input']
            khuj_value = request.POST['khuj']

            if len(input_values.strip()) == 0:
                messages.warning(request, "Input value can not be empty!")

            if len(khuj_value.strip()) == 0:
                messages.warning(request, "Khuj value can not be empty!")

            user_id = request.session['username']
            date = datetime.today()


            if khuj_value in input_values:
                messages.success(request, "True!")
            else:
                messages.warning(request, "False!")

            info = Info(user_id = user_id, input_values = input_values, timestamp=date)
            info.save()

        return render(request, 'index.html')

def signup(request):
    if request.method == "POST":
        username = request.POST['username']
        name = request.POST['name']
        password = request.POST['password']
        cpassword = request.POST['cpassword']
        
        #Validation
        flag = False
        if len(username.strip()) == 0:
            messages.warning(request, "Username can not be empty!")
            flag = True

        if(Visitor.objects.filter(username=username).count() != 0):
            messages.warning(request, "Username already exist!")
            flag = True

        if len(name.strip()) == 0:
            messages.warning(request, "Name can not be empty!")
            flag =True

        if len(password.strip()) == 0:
            messages.warning(request, "Password can not be empty!")
            flag =True

        if len(cpassword.strip()) == 0:
            messages.warning(request, "Confirm Password can not be empty!")

            flag =True
        
        if password != cpassword:
            messages.warning(request, "Password didn't match!")
            flag =True

        #CONVERTING TO MODEL
        myUser = Visitor(username=username, name=name, password=password)

        if not flag:
            myUser.save()
            messages.success(request, "Your Account has been successfully created!")
            return redirect('/')
        else:
            return redirect('/signup', {'username': myUser.username, 'name': myUser.name})

    return render(request,'signup.html')

def signin(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        flag = False

        if len(username.strip()) == 0:
            messages.warning(request, "Enter username and passwor to Sign in!")
            flag = True
        if len(password.strip()) == 0:
            messages.warning(request, "Password can not be empty!")
            flag =True
        if not flag and len(Visitor.objects.filter(username=username, password=password)):
            request.session['is_logged'] = True
            request.session['username'] = username
            return redirect('index')
    return render(request,'signin.html')

def signout(request):
    del request.session["is_logged"]
    del request.session["username"]
    return redirect('/')


@api_view(['GET'])
def getData(request):
    items = Info.objects.all()
    serializer = InfoSerializer(items,many=True)
    return Response(serializer.data)
