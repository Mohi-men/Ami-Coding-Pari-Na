from django.contrib import admin
from app_acpn.models import Info, Visitor
# Register your models here.
admin.site.register(Info)
admin.site.register(Visitor)